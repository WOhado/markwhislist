-- 3357650 Manifest and Lua created by Evan
-- PRAGMATA
-- Created: April 27, 2026 at 07:00:47 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3357650) -- PRAGMATA

-- MAIN APP DEPOTS
addappid(3357651) -- Depot 3357651
setManifestid(3357651, "2417499809052404547", 36816287661)
addappid(3859920) -- Depot 3859920
setManifestid(3859920, "4731286747379700304", 90058268)
addappid(3859930) -- Depot 3859930
setManifestid(3859930, "6714427611547107917", 298857949)