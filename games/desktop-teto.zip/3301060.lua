-- 3301060 Manifest and Lua created by Evan
-- Desktop Mate
-- Created: April 27, 2026 at 07:00:37 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3301060) -- Desktop Mate

-- MAIN APP DEPOTS
addappid(3301061) -- Depot 3301061
setManifestid(3301061, "246299916316269334", 213473290)
addappid(3301062) -- Depot 3301062
setManifestid(3301062, "7818352499584362299", 551169)
addappid(3301063) -- Depot 3301063
setManifestid(3301063, "5106986006190347865", 8544662)