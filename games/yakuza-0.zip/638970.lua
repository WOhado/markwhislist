-- 638970 Manifest and Lua created by Evan
-- Yakuza 0
-- Created: April 27, 2026 at 07:02:23 (UTC)
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(638970) -- Yakuza 0

-- MAIN APP DEPOTS
addappid(638971) -- Depot 638971
setManifestid(638971, "1004322381902797484", 23954947987)
addappid(638972) -- Depot 638972
setManifestid(638972, "5662079231198794978", 2328419544)
addappid(638973) -- Depot 638973
setManifestid(638973, "5399542270646326264", 2327909428)
addappid(638974) -- Depot 638974
setManifestid(638974, "9807815271788584", 0)
addappid(638975) -- Depot 638975
setManifestid(638975, "3296848567477597179", 202936810)