-- 367520 Manifest and Lua created by Evan
-- Hollow Knight
-- Created: April 27, 2026 at 07:00:29 (UTC)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(367520) -- Hollow Knight

-- MAIN APP DEPOTS
addappid(367521) -- Depot 367521
setManifestid(367521, "257781644874438846", 5231995691)
addappid(367522) -- Depot 367522
setManifestid(367522, "6809616861563627670", 5284750173)
addappid(367523) -- Depot 367523
setManifestid(367523, "708613018541602983", 5241907316)