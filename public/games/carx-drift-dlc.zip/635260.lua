-- 635260 Manifest and Lua created by Evan
-- CarX Drift Racing Online
-- Created: April 27, 2026 at 07:00:21 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(635260) -- CarX Drift Racing Online

-- MAIN APP DEPOTS
addappid(635261) -- Depot 635261
setManifestid(635261, "8962933129874924656", 8658771804)