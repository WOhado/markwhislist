-- 2102520's Lua and Manifest Created by Hubcap Manifest
-- Apex Point
-- Created: September 28, 2025 at 22:46:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2102520) -- Apex Point
-- MAIN APP DEPOTS
addappid(2102521, 1, "01608c961b88d8bf7b87e76c74e85a2bb9a9b9a33b5373b4f92049da6de55c78") -- Depot 2102521
setManifestid(2102521, "6029858606313865812", 6221957075)