-- 3058630 Manifest and Lua created by Evan
-- Assetto Corsa EVO
-- Created: April 27, 2026 at 07:00:16 (UTC)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3058630) -- Assetto Corsa EVO

-- MAIN APP DEPOTS
addappid(3058631) -- Depot 3058631
setManifestid(3058631, "4282907516108418173", 71118261246)