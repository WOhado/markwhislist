-- 250900 Manifest and Lua created by Evan
-- The Binding of Isaac: Rebirth
-- Created: April 27, 2026 at 07:00:25 (UTC)
-- Total Depots: 11
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(250900) -- The Binding of Isaac: Rebirth

-- MAIN APP DEPOTS
addappid(250902) -- Depot 250902
setManifestid(250902, "4994611894646808503", 326498528)
addappid(250903) -- Depot 250903
setManifestid(250903, "367036646469636831", 329786149)
addappid(250904) -- Depot 250904
setManifestid(250904, "1942665726573884808", 326357115)
addappid(250905) -- Depot 250905
setManifestid(250905, "1709017229885880564", 165283102)
addappid(250906) -- Depot 250906
setManifestid(250906, "274330258716671855", 171738462)
addappid(250907) -- Depot 250907
setManifestid(250907, "1258401244940465981", 184351160)
addappid(250908) -- Depot 250908
setManifestid(250908, "7333987924869605149", 147989670)
addappid(250909) -- Depot 250909
setManifestid(250909, "5041024818858406088", 135160872)
addappid(250910) -- Depot 250910
setManifestid(250910, "1079085999450784617", 175342144)
addappid(250911) -- Depot 250911
setManifestid(250911, "7652847940910762229", 655313480)
addappid(3353471) -- Depot 3353471
setManifestid(3353471, "229910742625134068", 763003388)